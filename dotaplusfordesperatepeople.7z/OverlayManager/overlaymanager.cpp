#include "overlaymanager.h"
#include <QApplication>
#include <QPainter>
#include <QScreen>

OverlayManager::OverlayManager(QWidget *parent)
    : QWidget(parent), displayText("")
{
    setWindowFlags(Qt::FramelessWindowHint
                   | Qt::WindowStaysOnTopHint
                   | Qt::Tool
                   | Qt::WindowTransparentForInput);
    setAttribute(Qt::WA_ShowWithoutActivating);
    setAttribute(Qt::WA_TranslucentBackground);
    setFocusPolicy(Qt::NoFocus);

    QScreen* screen = QGuiApplication::primaryScreen();
    if (screen) {
        QRect screenGeometry = screen->geometry();
        resize(screenGeometry.size());
    } else {
        resize(800, 600);
    }

    opacityEffect = new QGraphicsOpacityEffect(this);
    this->setGraphicsEffect(opacityEffect);
    opacityEffect->setOpacity(1.0);

    fadeAnimation = new QPropertyAnimation(opacityEffect, "opacity", this);
    fadeAnimation->setDuration(12000);
    fadeAnimation->setStartValue(1.0);
    fadeAnimation->setEndValue(0.0);

    connect(fadeAnimation, &QPropertyAnimation::finished, this, &QWidget::close);
}

void OverlayManager::showOverlay()
{
    showFullScreen();
    fadeAnimation->start();
}

void OverlayManager::setOverlayText(const QString &newText)
{
    displayText = newText;
    update();  // Repaint the widget with the new text
}

void OverlayManager::paintEvent(QPaintEvent* event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::TextAntialiasing);
    painter.setPen(Qt::red);
    painter.setFont(QFont("Arial", 48, QFont::Bold));

    // Draw the text centered on the screen
    QRect rect = this->rect();
    painter.drawText(rect, Qt::AlignCenter, displayText);
}

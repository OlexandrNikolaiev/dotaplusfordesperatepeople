#ifndef SOUNDMANAGER_H
#define SOUNDMANAGER_H

class SoundManager
{
public:
    SoundManager();
};

#endif // SOUNDMANAGER_H

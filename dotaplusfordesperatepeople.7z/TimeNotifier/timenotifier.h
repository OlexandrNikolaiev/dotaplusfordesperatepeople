#ifndef TIMENOTIFIER_H
#define TIMENOTIFIER_H
#include <QString>
#include <QDebug>
#include <unordered_map>
#include <QThread>
#include <QTimer>

#include "../OverlayManager/overlaymanager.h"
#include "../OverlayManager/overlayworker.h"

struct TimeEvent {
    QString soundFile;
    QString textOverlay;
};

class TimeNotifier : public QObject
{
public:
    TimeNotifier();
    void handleTimeEvent(char timeInGame[7]);

private:
    void playSound(const QString& file);
    void showTextOverlay(const QString& text);

    OverlayManager overlay;
};

#endif // TIMENOTIFIER_H
